#!/usr/bin/env bash

git add .

git commit -m "merge"

git push origin master



