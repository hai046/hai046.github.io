#!/usr/bin/env bash

bundle exec jekyll serve &
sleep 5
open http://localhost:4000


